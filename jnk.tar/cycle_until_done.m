%
while 1
  pause(3)
  if(exist('DONE'))
    delete('DONE')
    return
  end;
end;


